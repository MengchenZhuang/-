/**
 * jarekzha
 */
module touch {
    /**
     * 空命令
     */
    export class LevelNullCmd extends LevelCmd { }
}