/**
 * jarekzha
 */
module touch {
    /**
     * 显示文字
     */
    export class TextCmd extends LevelCmd {
        /**
         * 构造
         * @param data 
         */
        constructor(data: LevelCommandData) {
            super(data)
        }
    }
}