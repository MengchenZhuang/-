/**
 * jarekzha
 */
module touch {
    /**
     * 对象命令
     * object "Texture name", <xPosition>, <yPosition>, <Angle>, <Animation name>, <Duration>,
                <zOrder>, <textureFrameIndex>, <waterCirclesRepeatPeriod>
   - displays game object (any texture); similar to command texture (but can have animations etc.)
   - if zOrder > 0, then it is calculated from <xPosition>, <yPosition>
     */
}