/**
 * jarekzha
 */
module touch {
    /**
     * 战斗区域定义,以右下角为原点
     */
    export class FightAreaResData {
        /**地板的上下边 */
        public static FloorBottomY = -10
        public static FloorTopY = 180
        /**怪物出生的x点 */
        public static MonsterBornX = 80
    }
}