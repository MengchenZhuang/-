/**
 * jarekzha
 */
module touch {
    /**
     * 环境参数
     */
    export class Env {
        public static debug = true
    }
}