/**
* momo 
*/
module touch {
	/**
	 * 碎片类型枚举
	 */
	export enum EChip {
		WHITE_8,
		BLUE_8,
		GREEN_8,
		PURPLE_7,
		RED_6,
		BLUE_6,
		LIGHT_BLUE_6,
		YELLOW_4,
		PURPLE_4
	}
}