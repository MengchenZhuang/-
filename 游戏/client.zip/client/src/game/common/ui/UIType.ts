/**
* name 
*/
module touch{
	export enum EUIType{
		/**
		 * 
		 */
		VIEW,
		/**
		 * 
		 */
		DIALOG
	}
}