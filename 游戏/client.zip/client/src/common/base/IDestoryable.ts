/**
* momo 
*/
module touch {
	/**
	 * 可销毁基类
	 */
	export interface IDestoryable {
		/**
		 * 销毁函数
		 */
		destroy(): void;
	}
}