/**
  * 游戏数据存储vo
  * by dily
  * (c) copyright 2014 - 2035
  * All Rights Reserved.
  */
var GameVO = (function () {
    function GameVO() {
        /**
         * 框架名称
        */
        this.gameName = "Eger pro";
    }
    var d = __define,c=GameVO;p=c.prototype;
    return GameVO;
})();
egret.registerClass(GameVO,"GameVO");
