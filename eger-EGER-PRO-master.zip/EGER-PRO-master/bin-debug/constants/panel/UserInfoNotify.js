/**
* 用户信息
* by dily
* (c) copyright 2014 - 2035
* All Rights Reserved.
*/
var UserInfoNotify = (function () {
    function UserInfoNotify() {
    }
    var d = __define,c=UserInfoNotify;p=c.prototype;
    //打开角色
    UserInfoNotify.UPDATE_DATA = "UPDATE_DATA";
    return UserInfoNotify;
})();
egret.registerClass(UserInfoNotify,"UserInfoNotify");
