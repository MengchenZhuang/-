/**
  * 场景消息
  * by dily
  * (c) copyright 2014 - 2035
  * All Rights Reserved.
  */
var SceneNotify = (function () {
    function SceneNotify() {
    }
    var d = __define,c=SceneNotify;p=c.prototype;
    //打开主城场景
    SceneNotify.OPEN_HOME = "SceneNotify_OPEN_HOME";
    //关闭主城场景
    SceneNotify.CLOSE_HOME = "SceneNotify_CLOSE_HOME";
    return SceneNotify;
})();
egret.registerClass(SceneNotify,"SceneNotify");
