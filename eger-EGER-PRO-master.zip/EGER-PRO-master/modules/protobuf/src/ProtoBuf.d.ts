/**
 * Created by yangsong on 15-3-25.
 */
declare module dcodeIO{
    class ProtoBuf{
        static loadProto(protoContents:string):any;
    }
}