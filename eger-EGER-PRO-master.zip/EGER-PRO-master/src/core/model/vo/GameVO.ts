  /**
    * 游戏数据存储vo
    * by dily
    * (c) copyright 2014 - 2035
    * All Rights Reserved. 
    */
class GameVO {
    /**
     * 框架名称
    */
    public gameName: string = "Eger pro";
}
