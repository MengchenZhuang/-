/**
 * 角色信息
 */
module game {

    export class RoleInfo extends eui.Component {

        public constructor() {
            super();
            this.skinName = "src/core/view/main/RoleInfoSkin.exml";
        }
    }
}