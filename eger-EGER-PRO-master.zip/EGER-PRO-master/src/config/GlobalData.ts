/**
  * 全局数据存储
  * by dily
  * (c) copyright 2014 - 2035
  * All Rights Reserved. 
  */
module GlobalData {

    //我的名字
    export var myName: string = "dily";

}