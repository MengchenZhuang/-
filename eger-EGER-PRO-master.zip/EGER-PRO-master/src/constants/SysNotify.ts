  /**
	* 系统消息
	* by dily
	* (c) copyright 2014 - 2035
	* All Rights Reserved. 
    */
class SysNotify{
		public constructor(){

		}

        //服务器连接成功
        public static CONNECT_SERVER_SUCCESS: string = "CONNECT_SERVER_SUCCESS";
        //服务器返回数据
        public static SERVER_BACK_DATA: string = "SERVER_BACK_DATA";

	}	



