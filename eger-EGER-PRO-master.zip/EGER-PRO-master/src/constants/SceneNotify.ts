  /**
	* 场景消息
	* by dily
	* (c) copyright 2014 - 2035
	* All Rights Reserved. 
    */
	class SceneNotify{
		public constructor(){

		}

		//打开主城场景
		public static OPEN_HOME:string = "SceneNotify_OPEN_HOME";

		//关闭主城场景
		public static CLOSE_HOME:string = "SceneNotify_CLOSE_HOME";

	}	



