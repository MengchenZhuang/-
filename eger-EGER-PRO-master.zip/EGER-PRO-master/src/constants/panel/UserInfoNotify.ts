	/**
	* 用户信息
	* by dily
	* (c) copyright 2014 - 2035
	* All Rights Reserved. 
	*/
class UserInfoNotify{
	public constructor(){

	}

	//打开角色
    public static UPDATE_DATA: string = "UPDATE_DATA";


}	



