  /**
	* 主界面消息
	* by dily
	* (c) copyright 2014 - 2035
	* All Rights Reserved. 
	* 包括 角色UI、主功能、活动等等
    */
	class MainNotify{
		public constructor(){

		}

        //打开主界面UI
        public static OPEN_MAIN: string = "MainNotify_OPEN_MAIN";

        //关闭主界面UI
        public static CLOSE_MAIN: string = "MainNotify_CLOSE_MAIN";
        
		//打开角色UI
		public static OPEN_ROLE:string = "MainNotify_OPEN_ROLE";

		//关闭角色UI
		public static CLOSE_ROLE:string = "MainNotify_CLOSE_ROLE";

		//打开功能UI
		public static OPEN_FUNCTION:string = "MainNotify_OPEN_FUNCTION";

		//关闭功能UI
		public static CLOSE_FUNCTION:string = "MainNotify_CLOSE_FUNCTION";

		//打开活动UI
		public static OPEN_ACTIVITY:string = "MainNotify_OPEN_ACTIVITY";

		//关闭活动UI
		public static CLOSE_ACTIVITY:string = "MainNotify_CLOSE_ACTIVITY";
	}	



