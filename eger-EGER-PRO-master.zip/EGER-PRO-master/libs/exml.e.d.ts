declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare module main{
	class ActivityBtnSkin extends eui.Skin{
	}
}
declare module main{
	class BackpackBtnSkin extends eui.Skin{
	}
}
declare module main{
	class ChuangDangBtnSkin extends eui.Skin{
	}
}
declare module main{
	class CloseBtnSkin extends eui.Skin{
	}
}
declare module main{
	class InfoBtnSkin extends eui.Skin{
	}
}
declare module main{
	class KaiFuBtnSkin extends eui.Skin{
	}
}
declare module main{
	class MainBtnSkin extends eui.Skin{
	}
}
declare module main{
	class MapBtnSkin extends eui.Skin{
	}
}
declare module main{
	class QianghuaBtnSkin extends eui.Skin{
	}
}
declare module main{
	class RoleBtnSkin extends eui.Skin{
	}
}
declare module main{
	class ShopBtnSkin extends eui.Skin{
	}
}
declare module main{
	class ZhaoXianBtnSkin extends eui.Skin{
	}
}
declare class ActivityBarSkin extends eui.Skin{
}
declare class FunctionBarSkin extends eui.Skin{
}
declare class MainUISkin extends eui.Skin{
}
declare class RoleInfoSkin extends eui.Skin{
}
declare class BackpackSkin extends eui.Skin{
}
declare class ChuangDangSkin extends eui.Skin{
}
declare class MapSkin extends eui.Skin{
}
declare class QianghuaSkin extends eui.Skin{
}
declare class RoleSkin extends eui.Skin{
}
declare class ShopSkin extends eui.Skin{
}
declare class ZhaoXianSkin extends eui.Skin{
}
declare class HomeCitySkin extends eui.Skin{
}
