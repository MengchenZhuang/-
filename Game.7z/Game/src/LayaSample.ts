import WebGL = Laya.WebGL;
// 程序入口
class GameMain{
    constructor()
    {
        Laya.init(1334,750, WebGL);
        this.init();
    }

    private init():void
    {
        App.ModuleManager.instance.openUI(App.MainModule)
    }
}
new GameMain();