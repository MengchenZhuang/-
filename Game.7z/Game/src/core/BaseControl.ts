/**
* name 
*/
module App {
	export class BaseControl implements BaseObject{
		/**数据 */
		protected _data: BaseData;
		/**UI */
		protected _view: BaseView;
		/**
		 * 构造函数
		 */
		constructor() {

		}

		/**
		 * 初始化
		 * @param data 数据
		 * @param view 界面
		 */
		public initialize(data: BaseData, view: BaseView): void {
			this._data = data;
			this._view = view;
		}

		public onOpen(): void {
			this._view.initialize();
		}

		public onClose(): void {
			this.uninitialize();
		}

		/**
		 * 销毁
		 */
		public destroy(): void {
			alert("销毁，子类请重写...")
		}

		/**
		 * 反初始化
		 */
		public uninitialize(): void {
			if (this._view != null) {
				this.uninitialize();
			}
			this._data = null;
			this._view = null;
		}
	}
}