/**
* name 
*/
module App{
	export class BaseView implements BaseObject{
		constructor(){

		}

		/**
		 * 初始化
		 */
		public initialize():void
		{

		}

		/**
		 * 销毁
		 */
		public destroy():void
		{

		}

		/**
		 * 反初始化
		 */
		public uninitialize():void
		{

		}
	}
}