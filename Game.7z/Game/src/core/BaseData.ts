/**
* name 
*/
module App{
	export class BaseData implements BaseObject{
		/**
		 * 打开参数类
		 */
		public openParamClass: any = null;
		/**
		 * 是否打开
		 */
		public isOpened: boolean = false;
		/**
		 * 是否加载中
		 */
		public isLoading: boolean = false;
		/**
		 * 资源是否已经加载
		 */
		public isLoaded: boolean = false;
		/**
		 * 初始化
		 */
		public initialize(): void {
			//添加监听
		}

		/**
		 * 反初始化
		 */
		public uninitialize(): void {
			//移除监听
		}

		/**
		 * 销毁
		 */
		public destroy():void
		{

		}
	}
}