/**
* name 
*/
module App {
	export class BaseModule {
		/**
		 * 图集路径集合
		 */
		private _atlasUrls: Array<string> = null;
		/**
		 * 界面基本数据
		 */
		private _baseData: BaseData = null;
		/**控制器 */
		private _baseControl:BaseControl = null;
		/**界面 */
		private _baseView:BaseView = null;
		/**
		 * 进度句柄
		 */
		private _progressHandler: Laya.Handler = null;
		/**
		 * 界面类型
		 */
		private _type: EUIType = EUIType.VIEW;
		constructor(type: EUIType) {
			this._type = type;
			this._atlasUrls = new Array();
		}

		/**
		 * 注册数据
		 * @param dataClass 数据类
		 */
		public registData<T extends BaseData>(dataClass: { new (): BaseData }): void {
			if (this._baseData == null) {
				this._baseData = new dataClass();
				this._baseData.initialize();
			}
		}

		/**
		 * 注册view
		 * @param dataClass view类
		 */
		public registView<T extends BaseView>(dataClass: { new (): BaseView }): void {
			if (this._baseView == null) {
				this._baseView = new dataClass();
			}
		}

		/**
		 * 注册control
		 * @param dataClass control类
		 */
		public registControl<T extends BaseControl>(dataClass: { new (): BaseControl }): void {
			if (this._baseControl == null) {
				this._baseControl = new dataClass();
				this._baseControl.initialize(this._baseData,this._baseView);
			}
		}

		/**
		 * 打开界面
		 */
		public open(): void {
			if (this._baseData.isLoading || this._baseData.isOpened) {
				return;
			}
			if (this._baseData.isLoaded) {
				Laya.timer.callLater(this, this.doOpen);
			}
			else {
				Laya.timer.callLater(this, this.doLoad);
			}
		}

		/**
         *  执行加载 
         * 
         */
		private doLoad(): void {
			this._baseData.isLoading = true;
			this._progressHandler = Laya.Handler.create(this, this.onAtlasLoadProgress, null, false);
			if (this._atlasUrls.length > 0) {
				Laya.loader.load(this._atlasUrls, Laya.Handler.create(this, this.onAtlasLoadComplete),
					this._progressHandler);
			}
			else {
				this.onAtlasLoadComplete(true);
			}
		}

		/**
		 * 资源加载进度
		 * @param progress 进度
		 */
		private onAtlasLoadProgress(progress: number): void {

		}

		/**
		 * 资源加载完毕
		 */
		private onAtlasLoadComplete(result:boolean):void
		{
			if (this._progressHandler != null) {
				this._progressHandler.recover();
				this._progressHandler = null;
			}
			if (!result) {
				Laya.MouseManager.instance.disableMouseEvent = false;
				console.assert(false, "atlas 资源加载失败！");
				return;
			}
			this._baseData.isLoading = false;
			this.doOpen();
		}

		/**
		 * 添加图集
		 * @param atlasName 图集名字
		 */
		public addAtlas(atlasName: string): void {
			this._atlasUrls.push("res/atlas/" + atlasName + ".atlas");
		}
		
		/**
		 * 是否打开
		 */
		public get isOpen(): boolean {
			return this._baseData.isOpened;
		}

		/**
		 * 关闭UI
		 */
		public close(): void {
			Laya.timer.clear(this, this.doLoad);

			if (this._baseData.isLoading ||
				!this._baseData.isOpened) {
				return;
			}

			this.doHide();
		}

		/**
         *  执行隐藏
         * 
         */
		private doHide(): void {
			if (!this._baseData.isOpened) {
				return;
			}
			this._baseData.isOpened = true;
		}

		/**
		 * 被打开时
		 */
		protected onOpen(): void {
			this._baseControl.onOpen();
		}

		/**
         *  执行开启 
         * 
         */
		private doOpen(): void {
			this._baseData.isOpened = true;
			this.onOpen();
			ModuleManager.instance.event(UIEvent.OPEN, this);
		}

		/**
		 * 销毁
		 */
		public destroy(): void {
			if (this._atlasUrls != null) {
				Laya.loader.cancelLoadByUrls(this._atlasUrls);
				this._atlasUrls.splice(0, this._atlasUrls.length);
				this._atlasUrls = null;
			}

			this._baseData.uninitialize();
			this._baseData = null;

			Laya.loader.cancelLoadByUrls(this._atlasUrls);

			if (this._progressHandler != null) {
				this._progressHandler.recover();
				this._progressHandler = null;
			}
		}
	}
}