/**
* name 
*/
module App{
	export class ModuleManager extends Laya.EventDispatcher{
		/**模块管理 */
		private static _instance:ModuleManager;
		/**模块字典 */
		private _moduleDic:Laya.Dictionary;
		private constructor(){
			super();
			this._moduleDic = new Laya.Dictionary();
		}

		public static get instance():ModuleManager
		{
			if(this._instance == null)
			{
				this._instance = new ModuleManager();
			}
			return this._instance;
		}

		/**
		 * 打开模块
		 * @param classModule 模块类名称
		 */
		public openUI<T extends BaseModule>(classModule:{new ():T;}):void
		{
			let module: BaseModule = this._moduleDic.get(classModule);
			if (null == module) {
				module = new classModule();
				this._moduleDic.set(classModule, module);
				module.open();
			}
			else {
				console.log("模块已开启：" + classModule.prototype.constructor.name);
			}

			// return module;
		}

		/**
		 * 关闭模块
		 * @param classModule 模块类名称
		 */
		public closeUI<T extends BaseModule>(classModule:{new ():T}):void
		{
			let module: BaseModule = this._moduleDic.get(classModule);
			if (null != module) {
				this.event(UIEvent.CLOSE, ui);
				module.close();
				module.destroy();
				this._moduleDic.remove(module);
			}
			else {
				console.log("模块已关闭：" + classModule.prototype.constructor.name);
			}
		}

		/**
		 * 模块是否打开
		 * @param classModule 模块类名称
		 */
		public isOpen<T extends BaseModule>(classModule:{new ():T}):boolean
		{
			return this._moduleDic.indexOf(classModule) != -1
		}

		/**
		 * 获取模块
		 * @param classModule 模块类名称
		 */
		public getModule<T extends BaseModule>(classModule:{new ():BaseModule}):BaseModule
		{
			if(this._moduleDic.indexOf(classModule) != -1)
			{
				return this._moduleDic.get(classModule);
			}else
			{
				console.log("找不到模块：" + classModule.prototype.constructor.name);
			}	
		}
	}
}