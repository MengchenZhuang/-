module App{
	/**
	 * 界面事件
	 */
	export class UIEvent{
		/**
		 * 打开
		 */
		public static OPEN:string = "open";
		/**
		 * 关闭
		 */
		public static CLOSE:string = "close";
	}
}