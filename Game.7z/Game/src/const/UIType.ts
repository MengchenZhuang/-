/**
* name 
*/
module App{
	export enum EUIType{
		/**
		 * 
		 */
		VIEW,
		/**
		 * 
		 */
		DIALOG
	}
}