
import View=laya.ui.View;
import Dialog=laya.ui.Dialog;
module ui {
    export class MainUI extends View {
		public close:Laya.Button;
		public start:Laya.Button;

        public static  uiView:any ={"type":"View","props":{"width":1334,"height":750},"child":[{"type":"Image","props":{"y":0,"x":0,"width":1334,"skin":"comp/bg.png","sizeGrid":"36,25,18,18","height":750}},{"type":"Button","props":{"y":1,"x":1297,"width":36,"var":"close","skin":"comp/btn_close.png","height":33}},{"type":"Button","props":{"width":200,"var":"start","skin":"comp/button.png","labelSize":40,"label":"开始游戏","height":69,"centerY":0,"centerX":0}}]};
        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.createView(ui.MainUI.uiView);

        }

    }
}
