/**
* name 
*/
module App{
	export class MainView extends BaseView{
		/**界面 */
		private _ui:ui.MainUI;
		/**
		 * 销毁函数
		 */
		public destroy(): void {
			super.destroy();
		}

		/**
		 * 初始化
		 */
		public initialize(): void {
			this._ui = new ui.MainUI;
		}

		/**
		 * 反初始化
		 * @param 初始化参数
		 */
		public uninitialize(): void {
			if (this._ui != null) {
				this._ui.removeSelf();
				this._ui.destroy();
				this._ui = null;
			}
			super.uninitialize();
		}

		/**
		 * 获取界面
		 */
		public get ui(): ui.MainUI {
			return this._ui;
		}
	}
}