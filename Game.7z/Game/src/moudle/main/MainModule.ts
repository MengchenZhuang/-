/**
* name 
*/
module App{
	export class MainModule extends BaseModule{
		constructor(){
			super(EUIType.VIEW);
			this.addAtlas("comp")
			this.registData(MainData);
			this.registView(MainView);
			this.registControl(MainControl);
		}
	}
}