/**
* name 
*/
module App{
	export class MainControl extends BaseControl{
		/**
		 * ui
		 */
		private _ui:ui.MainUI;
		constructor(){
			super();
		}

		public onOpen():void
		{
			super.onOpen()
			this._ui = (this._view as MainView).ui;
			Laya.stage.addChild(this._ui);
			this._ui.close.clickHandler = Laya.Handler.create(this,this.close)
		}

		/**
		 * 关闭
		 */
		private close():void
		{
			this.onClose();
			ModuleManager.instance.closeUI(MainModule);
		}

		/**
		 * 反初始化
		 */
		public uninitialize():void
		{
			super.uninitialize();
		}

		private dispose():void
		{

		}
	}
}