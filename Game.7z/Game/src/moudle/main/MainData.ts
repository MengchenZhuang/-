/**
* name 
*/
module App{
	export class MainData extends BaseData{
		constructor(){
			super();
		}
	}
}