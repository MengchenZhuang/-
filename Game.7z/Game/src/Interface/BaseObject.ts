/**
* name 
*/
module App{
	export interface BaseObject{
		/**
		 * 初始化
		 */
		initialize(...data:any[]);
		/**
		 * 销毁
		 */
		destroy()
		/**
		 * 反初始化
		 */
		uninitialize();
	}
}